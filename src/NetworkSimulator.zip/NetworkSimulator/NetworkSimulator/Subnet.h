//
//  Subnet.h
//  NetworkSimulator
//
// 
//

#ifndef SUBNET_H
#define SUBNET_H

#include <string>
#include "Device.h"
#include <vector>

//Subnet Class: Handles subnetting

class Subnet {
public:
    std::string networkAddress;
    std::string subnetMask;
    std::vector<Device> devices;
    
    Subnet(std::string net, std::string mask);
    
    void addDevice(Device d);
};

#endif
