// We have done all the coding by ourselves and only copied the code that our professor provided to complete our labs and projects
// Group 10 Masoud Khire - 186174231 Jose Manuel Tiznado - 183725233 Ekjot Kaur- 189003239 Alan Joseph Guzman Gutierrez - 177035235   2026-04-05
//  NetworkUtils.cpp
//  NetworkSimulator
//
// 
//

#include "NetworkUtils.h"

std::string sendPacket(Device& sender, std::string targetIP, ARPTable& arp, Router& router) {
    std::string result = sender.getName() + " sending packet to " + targetIP + "\n";
    
    std::string mac = arp.resolve(targetIP);
    
    if (mac == "Not found") {
        result += "ARP Request broadcast...\n";
    } else {
       result += "MAC Found: " + mac + "\n";
    }
    std::string gateway = router.routePacket(targetIP);
    result += "Routing to " + gateway + "\n";
    return result;
}