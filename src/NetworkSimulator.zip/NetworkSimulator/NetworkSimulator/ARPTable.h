//
//  ARPTable.h
//  NetworkSimulator
//
// 
//

#ifndef ARPTABLE_H
#define ARPTABLE_H

#include <string>
#include <map>

//ARPTable Class: IP -> MAC mapping

class ARPTable {
public:
    std::map<std::string, std::string> table;
    
    void addEntry(std::string ip, std::string mac);
    
    std::string resolve(std::string ip);
};
#endif
