// We have done all the coding by ourselves and only copied the code that our professor provided to complete our labs and projects
// Group 10 Masoud Khire - 186174231 Jose Manuel Tiznado - 183725233 Ekjot Kaur- 189003239 Alan Joseph Guzman Gutierrez - 177035235   2026-04-05
//  Router.h
//  NetworkSimulator
//
//
//

#ifndef ROUTER_H
#define ROUTER_H

#include <string>
#include <map>
#include <iostream>

//Router class: Router + Static Routing

class Router {
public:
    std::map<std::string, std::string> routingTable;
    
    void addRoute(std::string destination, std::string nextHop);
    
    std::string routePacket(std::string destIP);

    std::string getGateway(std::string destIP);
};
#endif
