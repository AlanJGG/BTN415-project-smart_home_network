//
//  NetworkUtils.cpp
//  NetworkSimulator
//
// 
//

#include "NetworkUtils.h"

void sendPacket(Device& sender, std::string targetIP, ARPTable& arp, Router& router) {
    std::cout << sender.getName() << " sending packet to " << targetIP << "\n";
    
    std::string mac = arp.resolve(targetIP);
    
    if (mac == "Not found") {
        std::cout << "ARP Request broadcast...\n";
    } else {
        std::cout << "MAC Found: " << mac << "\n";
    }
    router.routePacket(targetIP);
}
