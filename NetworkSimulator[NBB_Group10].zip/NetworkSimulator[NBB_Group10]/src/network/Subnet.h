// We have done all the coding by ourselves and only copied the code that our professor provided to complete our labs and projects
// Group 10 Masoud Khire - 186174231 Jose Manuel Tiznado - 183725233 Ekjot Kaur- 189003239 Alan Joseph Guzman Gutierrez - 177035235   2026-04-05
//  Subnet.h
//  NetworkSimulator
//
// 
//

#ifndef SUBNET_H
#define SUBNET_H

#include <string>
#include "Device.h"
#include <vector>

//Subnet Class: Handles subnetting

class Subnet {
public:
    std::string networkAddress;
    std::string subnetMask;
    std::string gateway;
    std::vector<Device> devices;
    
    Subnet(std::string net, std::string mask, std::string gw);
    
    void addDevice(Device d);
    std::string getGateway() { return gateway; }
};

#endif
