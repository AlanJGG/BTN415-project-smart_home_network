// We have done all the coding by ourselves and only copied the code that our professor provided to complete our labs and projects
// Group 10 Masoud Khire - 186174231 Jose Manuel Tiznado - 183725233 Ekjot Kaur- 189003239 Alan Joseph Guzman Gutierrez - 177035235   2026-04-05

#ifndef PROTOCOL_PARSER_H
#define PROTOCOL_PARSER_H

#include <string>

struct Request
{
    std::string method;
    std::string device;
    std::string action;
    std::string value;
    bool valid;
    std::string errorMessage;
};

struct Response
{
    std::string statusCode;
    std::string body;

    std::string toString() const;
};

class ProtocolParser
{
public:
    static Request parseRequest(const std::string &rawRequest);
};

#endif
