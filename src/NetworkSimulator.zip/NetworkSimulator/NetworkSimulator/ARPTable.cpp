//
//  ARPTable.cpp
//  NetworkSimulator
//
//
//

#include "ARPTable.h"

void ARPTable::addEntry(std::string ip, std::string mac) {
    table[ip] = mac;
}

std::string ARPTable::resolve(std::string ip) {
    if (table.find(ip) != table.end())
        return table[ip];
    return "Not found";
}
