//
//  Subnet.cpp
//  NetworkSimulator
//
// 
//

#include "Subnet.h"

Subnet::Subnet(std::string net, std::string mask) : networkAddress(net), subnetMask(mask) {}

void Subnet::addDevice(Device d) {
    devices.push_back(d);
}
