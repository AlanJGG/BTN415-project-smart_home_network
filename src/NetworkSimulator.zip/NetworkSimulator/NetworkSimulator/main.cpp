//
//  main.cpp
//  NetworkSimulator
//
// 
//

#include <iostream>
#include "ARPTable.h"
#include "Device.h"
#include "Router.h"
#include "Subnet.h"
#include "NetworkUtils.h"

int main() {
    
    std::cout << "=== Network Design: Subnetting ===\n";
    
    // Network Design: 4 equal subnets (/26)
    Subnet lighting("192.168.1.0", "255.255.255.192"); //(0-63) = 192.168.1.10 -> Light
    Subnet thermostatNet("192.168.1.64", "255.255.255.192"); //(64-127) = 192.168.1.70 -> Thermostat
    Subnet security("192.168.1.128", "255.255.255.192");//(128-191) = 192.168.1.130 -> Security
    Subnet cameras("192.168.1.192", "255.255.255.192");//(192-255) = 192.168.1.200 -> Camera
    
    // Create Devices:
    Device light("Light1", "192.168.1.10", "AA:BB:CC:DD:01");
    Device thermostat("Thermo1", "192.168.1.70", "AA:BB:CC:DD:02");
    Device securityCam("Security1", "192.168.1.130", "AA:BB:CC:DD:03");
    Device camera("Camera1", "192.168.1.200", "AA:BB:CC:DD:04");
    
    // Assign devices to subnets:
    lighting.addDevice(light);
    thermostatNet.addDevice(thermostat);
    security.addDevice(securityCam);
    cameras.addDevice(camera);
    
    std::cout << "\nDevices assigned to subnets. \n";
    
    ARPTable arp;
    arp.addEntry("192.168.1.10", "AA:BB:CC:DD:01");
    arp.addEntry("192.168.1.70", "AA:BB:CC:DD:02");
    arp.addEntry("192.168.1.130", "AA:BB:CC:DD:03");
    arp.addEntry("192.168.1.200", "AA:BB:CC:DD:04");
    
    std::cout << "\nARP Table configured.\n";
    
    Router router;
    router.addRoute("192.168.1.0", "Lightning Gateway");
    router.addRoute("192.168.1.64", "Thermostat Gateway");
    router.addRoute("192.168.1.128", "Security Gateway");
    router.addRoute("192.168.1.192", "Camera Gateway");
    
    std::cout << "\n Router configured.\n";
    
    std::cout << "=== Simulation Start ===\n";
    
    sendPacket(light, "192.168.1.70", arp, router);
    std::cout << "\n";
    
    sendPacket(light, "192.168.1.130", arp, router);
    std::cout << "\n";
    
    sendPacket(thermostat, "192.168.1.200", arp, router);
    std::cout << "\n";
    
    sendPacket(light, "192.168.1.10", arp, router);
    std::cout << "\n";
    
    sendPacket(light, "192.168.1.250", arp, router); //FAIL TEST ONLY: ARP failure
    std::cout << "\n";
    
    std::cout << "=== Simulation End ===\n";
    
    return 0;
    
}
