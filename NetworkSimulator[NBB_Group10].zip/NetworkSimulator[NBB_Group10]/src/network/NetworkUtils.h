// We have done all the coding by ourselves and only copied the code that our professor provided to complete our labs and projects
// Group 10 Masoud Khire - 186174231 Jose Manuel Tiznado - 183725233 Ekjot Kaur- 189003239 Alan Joseph Guzman Gutierrez - 177035235   2026-04-05
//  NetworkUtils.h
//  NetworkSimulator
//
// 
//

#ifndef NETWORKUTILS_H
#define NETWORKUTILS_H

#include "Device.h"
#include "ARPTable.h"
#include "Router.h"
#include <string>
#include <iostream>

//For simulating communication

std::string sendPacket(Device& sender, std::string targetIP, ARPTable& arp, Router& router);

#endif
