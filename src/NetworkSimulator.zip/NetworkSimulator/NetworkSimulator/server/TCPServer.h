#ifndef TCP_SERVER_H
#define TCP_SERVER_H

#include <string>
#include <mutex>
#include "../../NetworkSimulator/Subnet.h"
#include "../utilities/SocketUtils.h"
#include "../../NetworkSimulator/Device.h"
#include "../../NetworkSimulator/ARPTable.h"
#include "../../NetworkSimulator/Router.h"
#include "../../NetworkSimulator/NetworkUtils.h"

class TCPServer
{
private:
    int m_port;
    socket_t m_serverSocket;
    std::mutex m_mutex;
    
    Device m_lightDevice;
    Device m_thermoDevice;
    Device m_cameraDevice;
    
    Subnet m_lighting;
    Subnet m_thermostatNet;
    Subnet m_cameras;
    
    ARPTable m_arp;
    Router router;

    class Light
    {
    private:
        bool m_isOn;

    public:
        Light();
        std::string on();
        std::string off();
        std::string status() const;
    };

    class Thermostat
    {
    private:
        int m_temp;

    public:
        Thermostat();
        std::string setTemp(int temp);
        std::string status() const;
    };

    class Camera
    {
    private:
        bool m_isOn;
        bool m_recording;

    public:
        Camera();
        std::string on();
        std::string off();
        std::string start();
        std::string stop();
        std::string status() const;
    };

    Light m_light;
    Thermostat m_thermostat;
    Camera m_camera;

    std::string processRequest(const std::string &request);
    void handleClient(socket_t clientSocket);

public:
    TCPServer(int port = 8080);
    ~TCPServer();

    void start();
};

#endif
